exports.config = require("./config");
exports.server = require("./server");
